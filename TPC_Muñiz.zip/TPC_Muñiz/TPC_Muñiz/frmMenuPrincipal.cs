﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TPC_Muñiz
{
    public partial class frmMenuPrincipal : Form
    {
        public frmMenuPrincipal()
        {
            InitializeComponent();
        }

        private void btnMostrarmMesas_Click(object sender, EventArgs e)
        {
            frmMesas Mesas = new frmMesas();
            Mesas.Show();
        }

        private void frmMenuPrincipal_FormClosed(object sender, FormClosedEventArgs e)
        {
            Environment.Exit(0);
        }

 

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void btnAgregarPlato_Click(object sender, EventArgs e)
        {
            frmAgregarPlato agregarPlato = new frmAgregarPlato();
            agregarPlato.Show();
        }

        private void btnAgregarBebida_Click(object sender, EventArgs e)
        {
            frmAgregarBebida AgregarBebida = new frmAgregarBebida();
            AgregarBebida.Show();
        }

        private void btnAgregarUsuario_Click(object sender, EventArgs e)
        {

        }
    }
}
