﻿namespace TPC_Muñiz
{
    partial class frmMenuPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAdministrarMesas = new System.Windows.Forms.Button();
            this.btnAgregarPlato = new System.Windows.Forms.Button();
            this.btnAgregarBebida = new System.Windows.Forms.Button();
            this.btnAgregarUsuario = new System.Windows.Forms.Button();
            this.btnSalir = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnAdministrarMesas
            // 
            this.btnAdministrarMesas.Location = new System.Drawing.Point(80, 48);
            this.btnAdministrarMesas.Name = "btnAdministrarMesas";
            this.btnAdministrarMesas.Size = new System.Drawing.Size(157, 40);
            this.btnAdministrarMesas.TabIndex = 0;
            this.btnAdministrarMesas.Text = "Administrar Mesas";
            this.btnAdministrarMesas.UseVisualStyleBackColor = true;
            this.btnAdministrarMesas.Click += new System.EventHandler(this.btnMostrarmMesas_Click);
            // 
            // btnAgregarPlato
            // 
            this.btnAgregarPlato.Location = new System.Drawing.Point(80, 94);
            this.btnAgregarPlato.Name = "btnAgregarPlato";
            this.btnAgregarPlato.Size = new System.Drawing.Size(157, 40);
            this.btnAgregarPlato.TabIndex = 1;
            this.btnAgregarPlato.Text = "Agregar Nuevo Plato";
            this.btnAgregarPlato.UseVisualStyleBackColor = true;
            this.btnAgregarPlato.Click += new System.EventHandler(this.btnAgregarPlato_Click);
            // 
            // btnAgregarBebida
            // 
            this.btnAgregarBebida.Location = new System.Drawing.Point(80, 140);
            this.btnAgregarBebida.Name = "btnAgregarBebida";
            this.btnAgregarBebida.Size = new System.Drawing.Size(157, 40);
            this.btnAgregarBebida.TabIndex = 2;
            this.btnAgregarBebida.Text = "Agregar Nueva Bebida";
            this.btnAgregarBebida.UseVisualStyleBackColor = true;
            this.btnAgregarBebida.Click += new System.EventHandler(this.btnAgregarBebida_Click);
            // 
            // btnAgregarUsuario
            // 
            this.btnAgregarUsuario.Location = new System.Drawing.Point(80, 186);
            this.btnAgregarUsuario.Name = "btnAgregarUsuario";
            this.btnAgregarUsuario.Size = new System.Drawing.Size(157, 40);
            this.btnAgregarUsuario.TabIndex = 3;
            this.btnAgregarUsuario.Text = "Agregar Usuario";
            this.btnAgregarUsuario.UseVisualStyleBackColor = true;
            this.btnAgregarUsuario.Click += new System.EventHandler(this.btnAgregarUsuario_Click);
            // 
            // btnSalir
            // 
            this.btnSalir.Location = new System.Drawing.Point(80, 232);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(157, 40);
            this.btnSalir.TabIndex = 4;
            this.btnSalir.Text = "Salir";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // frmMenuPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(322, 295);
            this.Controls.Add(this.btnSalir);
            this.Controls.Add(this.btnAgregarUsuario);
            this.Controls.Add(this.btnAgregarBebida);
            this.Controls.Add(this.btnAgregarPlato);
            this.Controls.Add(this.btnAdministrarMesas);
            this.Name = "frmMenuPrincipal";
            this.Text = "Menu Principal";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmMenuPrincipal_FormClosed);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnAdministrarMesas;
        private System.Windows.Forms.Button btnAgregarPlato;
        private System.Windows.Forms.Button btnAgregarBebida;
        private System.Windows.Forms.Button btnAgregarUsuario;
        private System.Windows.Forms.Button btnSalir;
    }
}