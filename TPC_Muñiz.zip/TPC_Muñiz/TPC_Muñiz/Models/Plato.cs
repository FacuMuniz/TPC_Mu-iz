﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
namespace TPC_Muñiz.Models
{
    class Plato
    {
        int id { get; set; }
        string descripcion { get; set; }
        float precio { get; set; }
        int cantidad { get; set; }
    }
}
